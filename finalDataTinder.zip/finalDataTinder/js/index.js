
	localStorage.clear();

	var a={
		"id":"1",
		"name":"Priya Khanna",
		"age":25,
		"work":"Developer",
		"place":"Net Max Solution",
		"dis":"14 Kilometer away"
	}
	var b={
		"id":"2",
		"name":"Preeti",
		"age":22,
		"work":"Student",
		"place":"Lambton College",
		"dis":"25 Kilometer away"

	}
	var c={
		"id":"3",
		"name":"Jasleen",
		"age":28,
		"work":"Sales Analyst",
		"place":"Rolex",
		"dis":"24 Kilometer away"
	}
	var d={
		"id":"4",
		"name":"Samantha",
		"age":21,
		"work":"Student",
		"place":"Ryerson University",
		"dis":"35 Kilometer away"
	}


	var people=[];
	people.push(a);
	people.push(b);
	people.push(c);
	people.push(d);

	var x=JSON.stringify(people);
	localStorage.setItem("people",x);
	var y=localStorage.getItem("people");
	var az =JSON.parse(y);
	var i=0;
	var check=0;




$(document).ready(function(){
	var imageChange = $("#likeImage");

	// if person swipes left, run the DISLIKE function (see below)
	imageChange.hammer().bind("swipeleft", dislikePicture);

	// if person swipes right, run the LIKE function (see below)
	imageChange.hammer().bind("swiperight", likePiture);

	function dislikePicture(ev)
	{
		i=i+1;

			$('.nope').show();
			setTimeout(
				function(){
				if(i==az.length){
					$("#likeImage").attr("src","img/logo.gif");
					$("#name").hide();
					$("#likedButton").attr("disabled","true");
					$("#dislikedButton").attr("disabled","true");
					check=2;
				}
			}, 1000);
			setTimeout(
			  function()
			  {
				$('.nope').hide();
				$("#likeImage").attr("src","img/"+az[i]["id"]+".jpg");
				$("#work").hide();
				$("#place").hide();
				$("#dis").hide();
				$("#name").text(az[i]["name"]+", "+az[i]["age"]);
				$("#work").text(az[i]["work"]);
				$("#place").text(az[i]["place"]);
				$("#dis").text(az[i]["dis"]);
			}, 1000);

	}

	// here is the LIKE function
	function likePiture(ev)
	{
		i=i+1;
		$('.like').show();
		setTimeout(
			function()
			{
			$('.like').hide();
			$("#work").hide();
			$("#place").hide();
			$("#dis").hide();

			$("#likeImage").attr("src","img/"+az[i]["id"]+".jpg");
			$("#name").text(az[i]["name"]+", "+az[i]["age"]);
			$("#work").text(az[i]["work"]);
			$("#place").text(az[i]["place"]);
			$("#dis").text(az[i]["dis"]);
			}, 1000);
		setTimeout(
			function(){
				if(i==az.length){
					$("#likeImage").attr("src","img/logo.gif");
					$("#name").hide();
					$("#likedButton").attr("disabled","true");
					$("#dislikedButton").attr("disabled","true");
					check=2;
				}
			}, 1000);
	}

	$("#likeImage").attr("src","img/"+az[i]["id"]+".jpg");
	$("#name").text(az[i]["name"]+", "+az[i]["age"]);
	$("#work").text(az[i]["work"]);
	$("#dis").text(az[i]["dis"]);
	$("#place").text(az[i]["place"]);
	$("#likeImage").click(function(){
		if(check==0){
			$('#work').slideDown().css("display","block");
			$('#dis').slideDown().css("display","block");
			$('#place').slideDown().css("display","block");
			check=1;
		}else if(check==2){

		}else{
			$('#work').slideUp();
			$('#dis').slideUp();
			$('#place').slideUp();
			check=0;
		}
	});

	$("#dislikedButton").click(function(){
		i=i+1;

			$('.nope').show();
			setTimeout(
			  function()
			  {
				$('.nope').hide();
				$("#likeImage").attr("src","img/"+az[i]["id"]+".jpg");
				$("#work").hide();
				$("#place").hide();
				$("#dis").hide();
				$("#name").text(az[i]["name"]+", "+az[i]["age"]);
				$("#work").text(az[i]["work"]);
				$("#place").text(az[i]["place"]);
				$("#dis").text(az[i]["dis"]);
			}, 1000);
			setTimeout(
			function(){
				if(i==az.length){
					$("#likeImage").attr("src","img/logo.gif");
					$("#name").hide();
					$("#likedButton").attr("disabled","true");
					$("#dislikedButton").attr("disabled","true");
					check=2;
				}
			}, 1000);
	});
	$("#likedButton").click(function(){
		i=i+1;
		$('.like').show();
		setTimeout(
		  function()
		  {
			$('.like').hide();
			$("#work").hide();
			$("#place").hide();
			$("#dis").hide();
			$("#likeImage").attr("src","img/"+az[i]["id"]+".jpg");
			$("#name").text(az[i]["name"]+", "+az[i]["age"]);
			$("#work").text(az[i]["work"]);
			$("#place").text(az[i]["place"]);
			$("#dis").text(az[i]["dis"]);
		  }, 1000);
		setTimeout(
			function(){
				if(i==az.length){
					$("#likeImage").attr("src","img/logo.gif");
					$("#name").hide();
					$("#likedButton").attr("disabled","true");
					$("#dislikedButton").attr("disabled","true");
					check=2;

				}
			}, 1000);
	});
});
